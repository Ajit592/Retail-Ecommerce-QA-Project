QA Internship Assignment - Submission Package
--------------------------------------------
Included files:
- QA_Internship_Assignment_Solution.pdf
- QA_Internship_Assignment_Solution.docx
- ECommerceTest.java  (Selenium + TestNG sample)

How to run the Java test:
1. Install Java JDK and Maven (or add Selenium + TestNG jars manually).
2. Add ChromeDriver to your PATH or set webdriver.chrome.driver system property.
3. Create a Maven project and place ECommerceTest.java under src/test/java (package as needed).
4. Add dependencies for Selenium Java and TestNG in pom.xml.
5. Run with: mvn test  (or run via your IDE)

Notes:
- The test uses Thread.sleep for simplicity; replace with explicit waits (WebDriverWait) in production tests.
- The test uses standard_user credentials for saucedemo which are public demo credentials.
