// ECommerceTest.java
// Selenium + TestNG sample to login, add product to cart, and verify cart count.
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ECommerceTest {
    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Ensure chromedriver is on PATH or set webdriver.chrome.driver system property.
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void testAddToCart() throws InterruptedException {
        driver.get("https://www.saucedemo.com/");

        // Login
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();

        // Wait briefly for page to load (replace with explicit waits in real tests)
        Thread.sleep(1000);

        // Select product (Sauce Labs Backpack) and add to cart
        WebElement product = driver.findElement(By.xpath("//div[text()='Sauce Labs Backpack']"));
        product.click();
        driver.findElement(By.cssSelector(".btn_inventory")).click();

        // Verify cart count badge shows 1
        WebElement cartBadge = driver.findElement(By.className("shopping_cart_badge"));
        String cartCount = cartBadge.getText();
        Assert.assertEquals(cartCount, "1", "Cart count should be 1 after adding one product.");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
